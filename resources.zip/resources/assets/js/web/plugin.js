//
// $('.lightgallery').lightGallery({
//     mode: 'lg-slide-circular',
//     counter: false
// });

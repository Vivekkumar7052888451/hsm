'use strict'

import * as Turbo from '@hotwired/turbo'

window.Turbo = Turbo
Turbo.start()
export default Turbo

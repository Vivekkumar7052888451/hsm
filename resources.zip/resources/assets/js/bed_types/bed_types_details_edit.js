listenHiddenBsModal('#editBedTypeModal', function () {
    resetModalForm('#editBedTypeForm', '#editValidationErrorsBox');
    $('#btnEditSave').attr('disabled', false);
})


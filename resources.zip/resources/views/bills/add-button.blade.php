<a href="{{ route('bills.create') }}" class="btn btn-primary">{{__('messages.bill.new_bill')}}</a>

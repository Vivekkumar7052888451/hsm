@if ($row->vehicle_type == 1)
    Contractual
@else
    Owned
@endif

<div class="d-flex align-items-center mt-2">
    <a href="{{route('bed-types.show',$row->id)}}" class="text-decoration-none">{{$row->title}}</a>    
</div>


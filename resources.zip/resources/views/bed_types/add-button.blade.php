<a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#addBedTypeModal"
   class="btn btn-primary">{{ __('messages.bed_type.new_bed_type') }}</a>

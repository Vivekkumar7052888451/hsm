<div class="table-responsive">
    <table class="table table-striped border-bottom-0"
           id="advancedPaymentsTable">
        <thead>
        <tr class="fw-bold fs-6 text-muted">
            <th>{{ __('messages.advanced_payment.receipt_no') }}</th>
            <th>{{ __('messages.advanced_payment.patient') }}</th>
            <th>{{ __('messages.advanced_payment.date') }}</th>
            <th>{{ __('messages.advanced_payment.amount') }}</th>
            <th>{{ __('messages.common.action') }}</th>
        </tr>
        </thead>
        <tbody class="text-gray-600 fw-bold">
        </tbody>
    </table>
</div>

<div class="d-flex align-items-center mt-2">
    <a class="badge bg-light-info text-decoration-none" href="{{ route('advanced-payments.show',$row->id) }}">{{ $row->receipt_no }}</a>    
</div>


<a href="javascript:void(0)" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAdvancedPaymentModal">
    {{__('messages.advanced_payment.new_advanced_payment')}}
</a>

{{ $row->ambulance->vehicle_model }}

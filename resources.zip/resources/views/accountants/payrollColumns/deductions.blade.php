<p class="text-end">{{ getCurrencyFormat($row->deductions) }}</p>

<a href="{{url('employee-payrolls', $row->id)}}"><span class="badge bg-light-info fs-6">{{ $row->payroll_id }}</span></a>

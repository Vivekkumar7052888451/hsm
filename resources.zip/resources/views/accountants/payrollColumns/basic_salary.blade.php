<p class="text-end">{{ getCurrencyFormat($row->basic_salary) }}</p>

<p class="text-end"><b>{{ getCurrencyFormat($row->net_salary) }}</p>

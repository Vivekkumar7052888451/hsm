<p class="text-end"><b>{{ getCurrencyFormat($row->allowance) }}</p>

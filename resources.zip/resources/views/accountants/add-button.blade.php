<a href="{{ route('accountants.create') }}"
   class="btn btn-primary">{{__('messages.accountant.new_accountant')}}</a>

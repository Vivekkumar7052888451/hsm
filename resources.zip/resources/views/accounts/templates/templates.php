<script id="accountIsActiveTemplate" type="text/x-jsrender">
<label class="form-check form-switch form-check-custom form-check-solid form-switch-sm">
         <input name="is-active" data-id="{{:id}}" class="form-check-input is-active" type="checkbox" value="1" {{:checked}} >
          <span class="switch-slider" data-checked="&#x2713;" data-unchecked="&#x2715;"></span>
    </label>



</script>

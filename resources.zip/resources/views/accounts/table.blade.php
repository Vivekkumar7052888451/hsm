<div class="table-responsive">
    <table class="table table-striped border-bottom-0"
           id="accountsTbl">
        <thead>
        <tr class="fw-bold fs-6 text-muted">
            <th>{{ __('messages.account.account') }}</th>
            <th>{{ __('messages.account.type') }}</th>
            <th>{{ __('messages.common.status') }}</th>
            <th>{{ __('messages.common.action') }}</th>
        </tr>
        </thead>
        <tbody class="text-gray-600 fw-bold">
        </tbody>
    </table>
</div>

<a href="javascript:void(0)" class="btn btn-primary" data-bs-toggle="modal"
   data-bs-target="#add_accounts_modal">{{__('messages.account.new_account')}}</a>

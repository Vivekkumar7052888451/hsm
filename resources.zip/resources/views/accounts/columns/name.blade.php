<div class="d-flex align-items-center mt-4">
    <a href="{{ route('accounts.show',$row->id) }}" class="text-decoration-none">{{ $row->name }}  </a>    
</div>


<div class="d-flex align-items-center mt-2">
    <a href="{{ url('beds').'/'.$row->bed->id }}" class="text-decoration-none">{{ $row->bed->name }}</a>    
</div>


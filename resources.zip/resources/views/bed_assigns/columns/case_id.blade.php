<div class="d-flex align-items-center mt-2">
    <a href="{{ url('patient-cases').'/'.$row->caseFromBedAssign->id }}" class="badge bg-light-info text-decoration-none">{{ $row->case_id }}</a>    
</div>


<script id="appointmentSlotTemplate" type="text/x-jsrender">
    <div class="time-slot">
        <span class="time-interval" data-id="{{:index}}">{{:timeSlot}}</span>
    </div>
</script>

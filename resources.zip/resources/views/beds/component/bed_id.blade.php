<div class="mt-3">
    <a href="{{ url('beds').'/'.$row->id }}" class="badge bg-light-info text-decoration-none">{{ $row->bed_id }}</a>    
</div>


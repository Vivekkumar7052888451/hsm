<div class="mt-3 d-flex justify-content-center">
    @if($row->is_available)
        <span class="badge bg-light-info">Yes</span>
    @else
        <span class="badge bg-light-danger">No</span>
    @endif    
</div>

    

<div class="mt-3">
    <a href="{{ route('bed-types.show',$row->bedType->id) }}" class="text-decoration-none">{{ $row->bedType->title }}</a>    
</div>


<div class="table-responsive">
    <table class="table table-striped border-bottom-0" id="bedsTbl">
        <thead>
        <tr class="fw-bold fs-6 text-muted">
            <th>{{ __('messages.bed.bed_id') }}</th>
            <th>{{ __('messages.bed_assign.bed') }}</th>
            <th>{{ __('messages.bed.bed_type') }}</th>
            <th>{{ __('messages.bed.charge') }}</th>
            <th>{{ __('messages.bed.available') }}</th>
            <th>{{ __('messages.common.action') }}</th>
        </tr>
        </thead>
        <tbody class="text-gray-600 fw-bold">
        </tbody>
    </table>
</div>

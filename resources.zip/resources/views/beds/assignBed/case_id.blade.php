<div class="badge bg-light-info"> {{$row->case_id}}</div>

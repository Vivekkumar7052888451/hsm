<a href="{{ route('admins.create') }}"
   class="btn btn-primary">{{__('messages.common.new')}} {{ __('messages.admin') }}</a>
